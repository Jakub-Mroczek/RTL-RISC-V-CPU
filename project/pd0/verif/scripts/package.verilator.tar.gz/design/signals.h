
`define ASSIGN_AND_X  assign_and_x
`define ASSIGN_AND_Y  assign_and_y
`define ASSIGN_AND_Z  assign_and_z

/* Your Code Below! Enable the following define's 
 * and replace ??? with actual wires */
// ----- signals -----
`define PROBE_EX33_ARESET  EX33_areset
`define PROBE_EX33_X       EX33_x
`define PROBE_EX33_Y       EX33_y
`define PROBE_EX33_Z       EX33_z

`define PROBE_EX34_X       EX34_x
`define PROBE_EX34_Y       EX34_y
`define PROBE_EX34_Z       EX34_z
// ----- signals -----

// ----- design -----
`define TOP_MODULE         pd0
// ----- design -----

